let currentIndex = 0;

function moveSlide(direction) {
  const slides = document.querySelectorAll('.carousel-item');
  const totalSlides = slides.length;
  
  currentIndex = (currentIndex + direction + totalSlides) % totalSlides;
  document.querySelector('.carousel-slide').style.transform = `translateX(-${currentIndex * 50}%)`;
};
// Função para atualizar o preço total com base na quantidade
function updateTotalPrice() {
  const pricePerUnit = 34.90; // Preço unitário do livro
  const quantity = parseInt(document.getElementById('quantity').value) || 1; // Obtém a quantidade, garantindo um valor válido
  document.getElementById('total-price').textContent = (pricePerUnit * quantity).toFixed(2); // Atualiza o preço total
}

// Função genérica para atualizar a quantidade
function updateQuantity(increment) {
  let quantity = parseInt(document.getElementById('quantity').value) || 1;
  quantity = Math.max(1, quantity + increment); // Garantir que a quantidade nunca seja menor que 1
  document.getElementById('quantity').value = quantity; // Atualiza o campo de entrada
  updateTotalPrice(); // Atualiza o preço total
}

// Event listeners para aumentar e diminuir a quantidade
document.getElementById('increase-btn').addEventListener('click', () => updateQuantity(1));
document.getElementById('decrease-btn').addEventListener('click', () => updateQuantity(-1));

// Event listener para o campo de entrada (caso o usuário digite diretamente)
document.getElementById('quantity').addEventListener('input', updateTotalPrice);

// Inicializa o preço total na carga da página
updateTotalPrice();
